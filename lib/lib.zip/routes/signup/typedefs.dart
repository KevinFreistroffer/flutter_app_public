typedef SetStepVisibility = void Function({
  bool showEmailAndUsername,
  bool showPasswords,
});
