class Styles {
  static const Map title = {'fontSize': 50.0};
  static const Map text = {'fontSize': 20.0};
  static const Map icon = {'size': 140.0};
}
