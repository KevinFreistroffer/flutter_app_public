class Macro {
  static final int calories = 1598;
  static final int fat = 133;
  static final int protein = 81;
  static final int carbs = 20;
}
