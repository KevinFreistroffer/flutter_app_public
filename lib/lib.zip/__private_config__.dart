class Config {
  static const password = '123Bs45Sd@@@';
}
